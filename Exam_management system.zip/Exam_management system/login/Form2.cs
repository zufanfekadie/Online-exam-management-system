﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using windowsFormsApplication1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApplication1
{

    public partial class Form2 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
       MySqlConnection con2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        
       

        public Form2()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form2_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form1 firstForm = new Form1();
            firstForm.Show();
            this.Hide();
        }
        bool success;
        private void button1_Click(object sender, EventArgs e)
        {


            if (!string.IsNullOrWhiteSpace(comboBox1.Text) && !string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(txtmail.Text) && !string.IsNullOrWhiteSpace(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox5.Text)  && !string.IsNullOrWhiteSpace(textBox3.Text) && !string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                if (success == true)
                {
                    if (txtmail.Text == textBox4.Text)
                    {
                        con.Open();


                        MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM Exam_management.teachers WHERE  FirstName=@fn ,LastName=@ln,Course=@co,username=@user,Password=@pass ", con);
                        cmd2 = new MySqlCommand("insert into Exam_management.teachers(FirstName,LastName,Course,username,Password,Sex,Email_adress) values(@fn,@ln,@co,@user,@pass,@sex,@Username)", con);


                        cmd2.Parameters.AddWithValue("@fn", textBox1.Text);
                        cmd2.Parameters.AddWithValue("@ln", textBox2.Text);
                        cmd2.Parameters.AddWithValue("@co", comboBox2.Text);
                        cmd2.Parameters.AddWithValue("@User", textBox3.Text);
                        cmd2.Parameters.AddWithValue("@pass", textBox5.Text);
                        cmd2.Parameters.AddWithValue("@sex", comboBox1.Text);
                        cmd2.Parameters.AddWithValue("@Username", txtmail.Text);
                        con.Close();
                       
                        con2.Open();
                        MySqlCommand cmd3 = new MySqlCommand("SELECT * FROM Exam_management.teachers WHERE Email_adress = @Username", con2);
                        MySqlCommand cmd4 = new MySqlCommand("SELECT * FROM Exam_management.teachers WHERE username = @User", con2);
                        cmd3.Parameters.AddWithValue("@Username", txtmail.Text);
                        cmd4.Parameters.AddWithValue("@User", textBox3.Text);
                        bool userExist = false;
                        bool usernameex=false;

                        using (var dr2 = cmd3.ExecuteReader())
                        
                            if (!(userExist = dr2.HasRows))
                            {
                                con2.Close();
                                con2.Open();
                                using (var dr3 = cmd4.ExecuteReader())
                                    if (!(usernameex = dr3.HasRows))
                                    {

                                    con2.Close();

                                    con.Open();
                                    cmd2.ExecuteNonQuery();
                                    MessageBox.Show("registered successfully");
                                    this.Hide();
                                    Form1 secondForm = new Form1();
                                    secondForm.Show();
                                    con.Close();
                                }
                                else { MessageBox.Show("user name already exists");con2.Close(); };
                            }
                            else
                            {

                                MessageBox.Show("email already exists");
                                con2.Close();
                            }
                    }
                    else { MessageBox.Show("emails don't match"); }
                }
                else { MessageBox.Show("please enter a valid email"); }
            }
                else
                {
                MessageBox.Show("please fill out all forms");
                }

        }






        private void txtmail_leave(object sender, EventArgs e)
        {
            string pattern = "^([0-9a-zA-Z]([-\\.\\w]*[0-9a-zA-Z])*@([0-9a-zA-Z][-\\w]*[0-9a-zA-Z]\\.)+[0-9a-zA-Z]{2,9})$";
            if (Regex.IsMatch(txtmail.Text, pattern))
            {
                errorProvider1.Clear();
                success = true;
            }
            else
            {
                errorProvider1.SetError(this.txtmail, "please provide valid mail adress");
                success = false;
            }


        }
        private void label6_Click(object sender, EventArgs e)
        {

        }
        private void label8_Click(object sender, EventArgs e)
        {
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 firstForm = new Form3();
            firstForm.Show();
            this.Hide();

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label9_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }
    }


    
}



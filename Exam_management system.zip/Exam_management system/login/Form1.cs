﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using WindowsFormsApplication1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;username=root;password=");
    
        public Form1()
        {
            InitializeComponent();
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }



        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {

        }

        private void linkLabel2_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Form2 secondForm = new Form2();
            secondForm.Show();
            this.Hide();
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
       
        private void button1_Click(object sender, EventArgs e)

        {


            if (!string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(txtmail2.Text) )
            {
                MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM Exam_management.teachers WHERE username= @UserName And Password=@pass", con);
                cmd1.Parameters.AddWithValue("@UserName", txtmail2.Text);
                cmd1.Parameters.AddWithValue("@pass", textBox2.Text);
                con.Open();
                bool userExists = false;
                using (var dr1 = cmd1.ExecuteReader())
                    if (userExists = dr1.HasRows)
                    {
                        MessageBox.Show("logged successfully");
                        this.Hide();
                        Form9 secondForm = new Form9();
                        secondForm.Show();
                       
                    }
               else
                {
                    MessageBox.Show("invalid UserName or password");
                }
                con.Close();
                
      
     
            }
            else
            {
                MessageBox.Show("please fill out all values");
            }
              
            
        }

                private void txtmail2_leave(object sender, EventArgs e)
                {

                }

                   private void Form1_Load(object sender, EventArgs e)
                      {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }
            
        

        private void button2_Click(object sender, EventArgs e)
        {
            Form3 firstForm = new Form3();
            firstForm.Show();
            this.Hide();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
        }
    
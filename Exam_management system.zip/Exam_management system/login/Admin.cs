﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;

namespace WindowsFormsApplication1
{
    public partial class Admin : Form
    {
        
        public Admin()
        {

            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
           

            InitializeComponent();
          
          
        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void Admin_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            MySqlConnection con2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            
           
            try
            {
             
                con2.Open();
                
                MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT * FROM exam_management.students", con2);

              
                DataTable table = new DataTable();
                dataGridView1.AutoGenerateColumns = false;
                adapter.Fill(table);

              
                dataGridView1.DataSource = table;

              
                adapter.Dispose();
                con2.Dispose();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                con2.Close();
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
           
        }

        private void button2_Click(object sender, EventArgs e)
        {

            MessageBox.Show("successfully saved!");
                this.Hide();
                Form12 fo = new Form12();
                fo.Show();
            
           
        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide(); 
            Form6 f= new Form6();
            f.Show();

        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
        }
        private void dataGridView1_MouseClick(object sender, MouseEventArgs e)
        {
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (this.dataGridView1.SelectedRows.Count == 1)
                {
                    string check= dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
            
                    if (check.Equals("NO"))
                    {
                        dataGridView1.SelectedRows[0].Cells[0].Value = "YES";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();
                       
                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM="+dataGridView1.SelectedRows[0].Cells[1].Value+"", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.SelectedRows[0].Cells[0].Value);
                         comand.ExecuteNonQuery();
                        dataGridView1.ClearSelection();

                        con3.Close();
                    }
                    else { 
                        dataGridView1.SelectedRows[0].Cells[0].Value = "NO";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

                        con3.Open();
                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al WHERE NUM="+dataGridView1.SelectedRows[0].Cells[1].Value+"", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.SelectedRows[0].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        dataGridView1.ClearSelection();
                        con3.Close();
                    }
                }
            }
        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
    
        }

        private void checkBox1_CheckedChanged_1(object sender, EventArgs e)
        {
           
            if (checkBox1.Checked==true)
            {
                for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "9")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "YES";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
            
           else if (checkBox1.Checked==false)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "9")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "NO";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox2.Checked==true)
            {
                for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
                {
                   
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "10")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "YES";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
          else  if (checkBox2.Checked == false)
            {
                for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "10")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "NO";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox3.Checked==true)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "11")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "YES";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
         else   if (checkBox3.Checked==false)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "11")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "NO";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

            if (checkBox4.Checked==true)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "12")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "YES";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
         else if (checkBox4.Checked==false)
            {
                for (int i = 0; i < dataGridView1.Rows.Count - 1; i++)
                {
                    string val = dataGridView1.Rows[i].Cells[5].Value.ToString();
                    if (val == "12")
                    {
                        dataGridView1.Rows[i].Cells[0].Value = "NO";
                        MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                        con3.Open();

                        MySqlCommand comand = new MySqlCommand(" UPDATE  exam_management.students SET aloowed=@al  WHERE NUM=" + dataGridView1.Rows[i].Cells[1].Value + "", con3);
                        comand.Parameters.AddWithValue("@al", dataGridView1.Rows[i].Cells[0].Value);
                        comand.ExecuteNonQuery();
                        con3.Close();
                    }
                }
            }
        }
    }
}

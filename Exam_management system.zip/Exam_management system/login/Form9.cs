﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using windowsFormsApplication1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApplication1
{
    public partial class Form9 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        public Form9()
        {
            InitializeComponent();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void Form9_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            MySqlConnection con2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            try
            {
                con2.Open();
                string st = "SELECT MAX(ID) from exam_management.questions";
                MySqlCommand cmd = new MySqlCommand(st, con2);
                int countt = (int)cmd.ExecuteScalar();
                textBox5.Text = Convert.ToString(countt + 1);
            }
            catch {
                textBox5.Text = "1";
            }
            finally { con2.Close(); }
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(comboBox1.Text)&&!string.IsNullOrWhiteSpace(textBox1.Text)) { 
            con.Open();
            MySqlCommand cmd2 = new MySqlCommand();
                cmd2 = new MySqlCommand("insert into Exam_management.questions(Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,ID) values(@qn,@ch1,@ch2,@ch3,@ch4,@ch5,@ans,@cu,@QNNO)", con);
            cmd2.Parameters.AddWithValue("@qn", textBox1.Text);
            cmd2.Parameters.AddWithValue("@ch1", textBox8.Text);
            cmd2.Parameters.AddWithValue("@ch2", textBox7.Text);
            cmd2.Parameters.AddWithValue("@ch3", textBox3.Text);
            cmd2.Parameters.AddWithValue("@ch4", textBox2.Text);
            cmd2.Parameters.AddWithValue("@ch5", textBox4.Text);
            cmd2.Parameters.AddWithValue("@ans", comboBox2.Text);
            cmd2.Parameters.AddWithValue("@cu", comboBox1.SelectedIndex+1);
            cmd2.Parameters.AddWithValue("@QNNO", textBox5.Text);


            cmd2.ExecuteNonQuery();
            con.Close();
            MessageBox.Show("successfully saved");
            this.Hide();
            Form9 newf = new Form9();
            newf.Show();
        }      else
            {
                MessageBox.Show("make sure you entered the question and the course first.");
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            con.Close();
            con.Open();
            MySqlCommand cmd2 = new MySqlCommand();
            if (!string.IsNullOrWhiteSpace(comboBox1.Text)&&!string.IsNullOrWhiteSpace(textBox5.Text))
            {
                cmd2 = new MySqlCommand("UPDATE Exam_management.questions SET Question=@qn,Choice_1=@ch1,Choice_2=@ch2,Choice_3=@ch3,Choice_4=@ch4,Choice_5=@ch5,Answer=@ans,Course=@cu Where  ID=@QNNO", con);

                
                cmd2.Parameters.AddWithValue("@qn", textBox1.Text);
                    cmd2.Parameters.AddWithValue("@ch1", textBox8.Text);
                    cmd2.Parameters.AddWithValue("@ch2", textBox7.Text);
                    cmd2.Parameters.AddWithValue("@ch3", textBox3.Text);
                    cmd2.Parameters.AddWithValue("@ch4", textBox2.Text);
                    cmd2.Parameters.AddWithValue("@ch5", textBox4.Text);
                    cmd2.Parameters.AddWithValue("@ans", comboBox2.Text);
                    cmd2.Parameters.AddWithValue("@cu", comboBox1.SelectedIndex + 1);
                    cmd2.Parameters.AddWithValue("@QNNO", textBox5.Text);
                    cmd2.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show("Successfully updated");
                
            }
            else
            {
                MessageBox.Show("please enter both the course and question number");

            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand cmd2 = new MySqlCommand();
            if (!string.IsNullOrWhiteSpace(comboBox1.Text)&&!string.IsNullOrWhiteSpace(textBox5.Text))
            {
                cmd2 = new MySqlCommand("Delete from Exam_management.questions Where ID=@QNNO", con);
                cmd2.Parameters.AddWithValue("@QNNO", int.Parse(textBox5.Text));
               cmd2.ExecuteNonQuery();
              con.Close();
              MessageBox.Show("succesfully deleted");
            }

            else
            {
                MessageBox.Show("please enter both the course and question number of the question you want to delete");

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 firstForm = new Form1();
            firstForm.Show();
            this.Hide();

        }

        private void button5_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void button5_Click_1(object sender, EventArgs e)
        {

        }

        private void button5_Click_2(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(comboBox1.Text)&&!string.IsNullOrWhiteSpace(textBox5.Text))
            {

                MySqlConnection c = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;user id=root;password=");
                try
                {

                    c.Open();
                    MySqlCommand cmd2 = new MySqlCommand("SELECT * FROM exam_management.questions where course=@cou", c);
                    cmd2.Parameters.AddWithValue("@cou", comboBox1.SelectedIndex + 1);
                    MySqlDataAdapter adapter = new MySqlDataAdapter();

                    adapter = new MySqlDataAdapter(cmd2);
                    DataTable table = new DataTable();
                    dataGridView1.AutoGenerateColumns = false;
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;
                    adapter.Dispose();
                    c.Dispose();
                }
                catch (Exception ex)
               {
               MessageBox.Show(ex.Message);
               }
               finally
               {
                   c.Close();
               }
            }
            else
            {
                MessageBox.Show("please enter the course first");

            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
          
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dataGridView1_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (dataGridView1.SelectedRows.Count>=0)
            {
                textBox5.Text = dataGridView1.SelectedRows[0].Cells[0].Value.ToString();
                textBox1.Text = dataGridView1.SelectedRows[0].Cells[1].Value.ToString();
                textBox8.Text = dataGridView1.SelectedRows[0].Cells[2].Value.ToString();
                textBox7.Text = dataGridView1.SelectedRows[0].Cells[3].Value.ToString();
                textBox3.Text = dataGridView1.SelectedRows[0].Cells[4].Value.ToString();
                textBox2.Text = dataGridView1.SelectedRows[0].Cells[5].Value.ToString();
                textBox4.Text = dataGridView1.SelectedRows[0].Cells[6].Value.ToString();
                comboBox2.Text = dataGridView1.SelectedRows[0].Cells[7].Value.ToString();
                comboBox1.Text = dataGridView1.SelectedRows[0].Cells[8].Value.ToString();
            }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            MySqlConnection c = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;user id=root;password=");
            c.Open();
            MySqlCommand cmd1 = new MySqlCommand();
            if (!string.IsNullOrWhiteSpace(textBox6.Text))
            {
                cmd1 = new MySqlCommand("SELECT * FROM exam_management.questions WHERE question like '" + textBox6.Text + "%'", c);
        
           
                bool QNExists = false;

                using (var dr1 = cmd1.ExecuteReader())
                    if (!(QNExists = dr1.HasRows)) { MessageBox.Show("Question  not available!"); c.Close(); }
                    else
                    {
                        try
                        {
                            c.Close();
                            c.Open();
                            MySqlDataAdapter adapter = new MySqlDataAdapter(cmd1);
                            DataTable table = new DataTable();
                            dataGridView1.AutoGenerateColumns = false;
                            adapter.Fill(table);
                            dataGridView1.DataSource = table;
                            adapter.Dispose();
                            c.Dispose();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }
                        finally
                        {
                            c.Close();
                        }

                    }

            }
            else
            { MessageBox.Show("please enter the question you want to search"); }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using windowsFormsApplication1;

namespace WindowsFormsApplication1
{
    public partial class Form4 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;username=root;password=");
        MySqlConnection con2 = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;username=root;password=");

      
        public Form4()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try {
                String alow = "YES";
                String notalow = "NO";
                if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    con.Close();
                    con.Open();
                    MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM Exam_management.students WHERE NUM= @id AND Password=@pass AND aloowed=@alo", con);

                    cmd1.Parameters.AddWithValue("@alo", alow);
                    cmd1.Parameters.AddWithValue("@id", textBox1.Text);
                    cmd1.Parameters.AddWithValue("@pass", textBox2.Text);
                    bool userExists = false;

                    using (var dr1 = cmd1.ExecuteReader())
                        if (userExists = dr1.HasRows)
                        {

                            MessageBox.Show("logged successfully");
                            con.Close();
                            con.Open();
                            MySqlCommand cm = new MySqlCommand("SELECT MAX(period) FROM exam_management.arranged_questions", con);
                            int result = (int)cm.ExecuteScalar();
                            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.examsession(QNNO,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  QNNO,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.arranged_questions Where period=@per", con);
                            command2.Parameters.AddWithValue("@per", result);
                            int d = 0;
                            MySqlCommand command = new MySqlCommand("UPDATE  exam_management.examsession SET id=@id WHERE id=@dd", con);
                            command.Parameters.AddWithValue("@dd", d);
                            command.Parameters.AddWithValue("@id", textBox1.Text);
                            command2.ExecuteNonQuery();
                            command.ExecuteNonQuery();
                            this.Hide();


                            MySqlCommand coo = new MySqlCommand("UPDATE  exam_management.students SET aloowed=@al WHERE NUM=@id", con);
                            coo.Parameters.AddWithValue("@id", textBox1.Text);
                            coo.Parameters.AddWithValue("@al", notalow);
                            coo.ExecuteNonQuery();
                            con.Close();
                            first f2 = new first(this);
                            f2.ShowDialog();


                        }
                        else
                        {
                            MessageBox.Show("invalid Information or Unallowed ID", "ERROR");
                        }
                }
                else
                {
                    MessageBox.Show("please fill out all values", "ERROR");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
         

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form4_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 firstForm = new Form8();
            firstForm.Show();
            this.Hide();

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}

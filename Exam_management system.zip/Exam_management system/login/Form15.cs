﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using windowsFormsApplication1;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApplication1
{
    public partial class Form15 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
        MySqlConnection con2 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

        public Form15()
        {
            
            InitializeComponent();
           

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void Form15_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox6.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(comboBox1.Text) && !string.IsNullOrWhiteSpace(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox3.Text) && !string.IsNullOrWhiteSpace(comboBox2.Text))
            {
                con.Open();

               MySqlCommand   cmd2 = new MySqlCommand("insert into Exam_management.students(FirstName,LastName,Sex,Password,NUM,class) values(@fn,@ln,@sex,@pass,@id,@class)", con);


                cmd2.Parameters.AddWithValue("@fn", textBox6.Text);
                cmd2.Parameters.AddWithValue("@ln", textBox2.Text);
                cmd2.Parameters.AddWithValue("@sex", comboBox1.Text);
                cmd2.Parameters.AddWithValue("@class", comboBox2.Text);
                cmd2.Parameters.AddWithValue("@pass", textBox3.Text);
                cmd2.Parameters.AddWithValue("@id", textBox4.Text);
                con.Close();

                con2.Open();
                MySqlCommand cmd3 = new MySqlCommand("SELECT * FROM Exam_management.students WHERE NUM= @id", con2);   
                cmd3.Parameters.AddWithValue("@id", textBox4.Text);
                bool userExist = false;
                using (var dr2 = cmd3.ExecuteReader())

                    if (!(userExist = dr2.HasRows))
                    {
                       
                        con2.Close();
                        con.Open();
                        cmd2.ExecuteNonQuery();
                        MessageBox.Show("registered successfully");
                        this.Hide();
                        Form4 secondForm = new Form4();
                        secondForm.Show();
                        con.Close();
                      
                   

                    }
                    else
                    {

                        MessageBox.Show("ID already exists");
                        this.Hide();
                        Form1 secondForm = new Form1();
                        secondForm.Show();

                    }
            }
            else
            {
                MessageBox.Show("please fill out all values");
            }

        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form8 firstForm = new Form8();
            firstForm.Show();
            this.Hide();

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}


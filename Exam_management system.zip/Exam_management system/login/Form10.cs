﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using WindowsFormsApplication1;

namespace WindowsFormsApplication1
{
    public partial class Form10 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;username=root;password=");
        MySqlCommand cmd;
        MySqlDataAdapter adapt;
        public Form10()
        {
            InitializeComponent();
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form10_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) )
            {
                MySqlCommand cmd1 = new MySqlCommand("SELECT * FROM Exam_management.admin WHERE  FirstName=@fn AND Password=@pass", con);
                
             
                cmd1.Parameters.AddWithValue("@fn", textBox1.Text);
                cmd1.Parameters.AddWithValue("@pass", textBox2.Text);
                con.Open();
                bool userExists = false;
                using (var dr1 = cmd1.ExecuteReader())
                    if (userExists = dr1.HasRows)
                    {
                        MessageBox.Show("logged successfully");
                        this.Hide();
                        Form6 secondForm = new Form6();
                        secondForm.Show();

                    }
                    else
                    {
                        MessageBox.Show("invalid name or password");
                    }

                con.Close();
               
            }
            else
            {
                MessageBox.Show("please fill out all values");
            }
            }

        private void button2_Click(object sender, EventArgs e)
        {
           

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form7 firstForm = new Form7();
            firstForm.Show();
            this.Hide();
        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }
    }
    }

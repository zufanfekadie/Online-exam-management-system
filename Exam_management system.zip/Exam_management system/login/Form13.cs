﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApplication1
{
    public partial class Form13 : Form
    {
        public Form13()
        {
            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            InitializeComponent();
            con.Open();
            
        }

        private void Form13_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void check_click1(object sender, EventArgs e)
        {

        }

        private void check_click2(object sender, EventArgs e)
        {

        }
    }
}

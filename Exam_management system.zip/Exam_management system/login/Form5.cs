﻿using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WindowsFormsApplication1
{
    public partial class Form5 : Form
    {
        MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

        public Form5()
        {
            InitializeComponent();
        }
        private void Form5_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            label8.Text = "0";
            textBox2.Text = "0";
            textBox1.Text = "0";
            textBox3.Text = "0";
            textBox4.Text = "0";
            textBox5.Text = "0";

            textBox6.Text = "0";
            textBox14.Text="0";
            con.Close();
            con.Open();
            try
            {

                string ct = " SELECT MAX(period) FROM exam_management.arranged_questions ";

                MySqlCommand cmdCount = new MySqlCommand(ct, con);

                int count2 = (int)cmdCount.ExecuteScalar();
                textBox13.Text = Convert.ToString(count2 + 1);
            }
            catch
            {
                textBox13.Text = "1";
            }
            finally { con.Close(); }


        }
        private void totmark() {
            double a = Convert.ToDouble(label14.Text);
            double B = Convert.ToDouble(label15.Text);
            double c = Convert.ToDouble(label16.Text);
            double d = Convert.ToDouble(label17.Text);
            double eE = Convert.ToDouble(label18.Text);
            double xx = Convert.ToDouble(label19.Text);
            label12.Text = Convert.ToString(a + B + c + d + eE + xx);
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void NewNumber()
        {
            int hm = Convert.ToInt32(textBox1.Text);
            con.Close();
            con.Open();

            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=1 ORDER BY RAND() LIMIT " + hm + "", con);
          
            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox7.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=1 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox7.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox7.Text);

            com.ExecuteNonQuery();
        }
        private void NewNumber2()
        {
            int hm = Convert.ToInt32(textBox2.Text);
            con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=2 ORDER BY RAND() LIMIT " + hm + "", con);

            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox8.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=2 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox8.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox8.Text);

            com.ExecuteNonQuery();
        }
        private void NewNumber3()
        {
            int hm = Convert.ToInt32(textBox3.Text);
            con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=3 ORDER BY RAND() LIMIT " + hm + "", con);

            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox9.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=3 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox9.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox9.Text);

            com.ExecuteNonQuery();
        }
        private void NewNumber4()
        {
            int hm = Convert.ToInt32(textBox4.Text);
            con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=4 ORDER BY RAND() LIMIT " + hm + "", con);

            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox10.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=4 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox10.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox10.Text);

            com.ExecuteNonQuery();
        }
        private void NewNumber5()
        {
            int hm = Convert.ToInt32(textBox5.Text);
            con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=5 ORDER BY RAND() LIMIT " + hm + "", con);

            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox11.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=5 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox11.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox11.Text);

            com.ExecuteNonQuery();
        }
        private void NewNumber6()
        {
            int h = int.Parse(textBox6.Text);
            int hm = Convert.ToInt32(textBox5.Text);
            con.Close();
            con.Open();
            MySqlCommand command = new MySqlCommand("UPDATE exam_management.questions SET period=@period,each_mark=@eachm Where course=6 ORDER BY RAND() LIMIT " + hm + "", con);

            command.Parameters.AddWithValue("@period", textBox13.Text);
            command.Parameters.AddWithValue("@eachm", textBox12.Text);
            command.ExecuteNonQuery();
            MySqlCommand command2 = new MySqlCommand("Insert into exam_management.arranged_questions(ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark) select  ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,period,each_mark FROM exam_management.questions Where course=6 AND period=@per", con);
            command2.Parameters.AddWithValue("@per", textBox13.Text);
            command2.Parameters.AddWithValue("@eachm", textBox12.Text);

            command2.ExecuteNonQuery();
            MySqlCommand com = new MySqlCommand("UPDATE  exam_management.questions SET period=NULL,each_mark=@eachm  where period=@per ", con);
            com.Parameters.AddWithValue("@per", textBox13.Text);
            com.Parameters.AddWithValue("@eachm", textBox12.Text);

            com.ExecuteNonQuery();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) && !string.IsNullOrWhiteSpace(textBox3.Text) && !string.IsNullOrWhiteSpace(textBox4.Text) && !string.IsNullOrWhiteSpace(textBox5.Text) && !string.IsNullOrWhiteSpace(textBox3.Text) && !string.IsNullOrWhiteSpace(textBox6.Text))

            {
                NewNumber();
                NewNumber2();
                NewNumber3();
                NewNumber4();
                NewNumber5();
                NewNumber6();

                DialogResult dialogResult = MessageBox.Show("successfully saved!", "message");

                MySqlConnection c = new MySqlConnection("datasource=localhost;Server=127.0.0.1;port=3306;user id=root;password=");
             
                    c.Open();
                    MySqlDataAdapter adapter = new MySqlDataAdapter("SELECT period,ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,each_mark FROM exam_management.arranged_questions WHERE period=" + textBox13.Text + "", c);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    dataGridView1.DataSource = table;
                    adapter.Dispose();
                    c.Dispose();
                progressBar1.Value = 0;
                progressBar1.Minimum = 0;
                progressBar1.Maximum = dataGridView1.Rows.Count - 1;
                progressBar1.Step = 1;
                MySqlConnection con3 = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
                con3.Open();
                MySqlCommand comand = new MySqlCommand(" delete from  exam_management.arranged_questions where 1", con3);
                comand.ExecuteNonQuery();

                con3.Close();
                for (int i = 0; i < dataGridView1.Rows.Count-1; i++)
                {
                    con3.Open();
                    this.dataGridView1.Rows[i].Cells[0].Value=(i+1).ToString();
                    this.dataGridView1.Rows[i].Cells[1].Value = textBox14.Text;
                        MySqlCommand cm = new MySqlCommand("insert into  exam_management.arranged_questions(QNNO,period,ID,Question,Choice_1,Choice_2,Choice_3,Choice_4,Choice_5,Answer,Course,each_mark,total_time) VALUES(@qn,@per,@id,@ques,@c1,@c2,@c3,@c4,@c5,@ans,@cou,@em,@tot)",con3);
                    cm.Parameters.AddWithValue("@qn", dataGridView1.Rows[i].Cells[0].Value);
                    cm.Parameters.AddWithValue("@per", dataGridView1.Rows[i].Cells[2].Value);
                    cm.Parameters.AddWithValue("@id", dataGridView1.Rows[i].Cells[3].Value);
                    cm.Parameters.AddWithValue("@ques", dataGridView1.Rows[i].Cells[4].Value);
                    cm.Parameters.AddWithValue("@c1", dataGridView1.Rows[i].Cells[5].Value);
                    cm.Parameters.AddWithValue("@c2", dataGridView1.Rows[i].Cells[6].Value);
                    cm.Parameters.AddWithValue("@c3", dataGridView1.Rows[i].Cells[7].Value);
                    cm.Parameters.AddWithValue("@c4", dataGridView1.Rows[i].Cells[8].Value);
                    cm.Parameters.AddWithValue("@c5", dataGridView1.Rows[i].Cells[9].Value);
                    cm.Parameters.AddWithValue("@ans", dataGridView1.Rows[i].Cells[10].Value);
                    cm.Parameters.AddWithValue("@cou", dataGridView1.Rows[i].Cells[11].Value);
                    cm.Parameters.AddWithValue("@em", dataGridView1.Rows[i].Cells[12].Value);
                    cm.Parameters.AddWithValue("@tot", Convert.ToInt32( dataGridView1.Rows[i].Cells[1].Value));
                    cm.ExecuteNonQuery();
                    con3.Close();
                    progressBar1.PerformStep();
                }
                MessageBox.Show("exam prepared successfuly!!", "message");
                this.Close();
                Form12 form12 = new Form12();
                form12.Show();

        
            }
            else
            {
                MessageBox.Show("please fill out all values (fill 0 for those you want to be empty");
            }
            con.Close();
            con.Open();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Hide();
           Form6 admin = new Form6();
            admin.Show();
        }
        private void A()
        {
            con.Close();

            string ct = " SELECT count(ID) FROM exam_management.Questions where course=1";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);
            con.Open();
            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
           

            if (Convert.ToInt32(textBox1.Text) > count)
            {

                MessageBox.Show("the number of math questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox1.Text);

                label8.Text = Convert.ToString(c - d);

                textBox1.Text = "0";
            }
            con.Close();
        }
        private void B()
        {

            con.Close();
            string ct = " SELECT count(ID) FROM exam_management.Questions where course=2";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);
            con.Open();
            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
          
            if (Convert.ToInt32(textBox2.Text) > count)
            {
                MessageBox.Show("the number of english questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox2.Text);

                label8.Text = Convert.ToString(c - d);

                textBox2.Text = "0";

            }

        }
        private void C()
        {

            con.Close();
            string ct = " SELECT count(ID) FROM exam_management.Questions where course=3";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);
            con.Open();
            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
     
            if (Convert.ToInt32(textBox3.Text) > count)
            {
                MessageBox.Show("the number of biology questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox3.Text);

                label8.Text = Convert.ToString(c - d);

                textBox3.Text = "0";
            }

        }
        private void D()
        {

            con.Close();
            string ct = " SELECT count(ID) FROM exam_management.Questions where course=4";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);
            con.Open();
            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
           
            if (Convert.ToInt32(textBox4.Text) > count)
            {
                MessageBox.Show("the number of chemistry questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox4.Text);

                label8.Text = Convert.ToString(c - d);

                textBox4.Text = "0";
            }

        }
        private void E()
        {

            con.Close();
            string ct = " SELECT count(ID) FROM exam_management.Questions where course=5";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);
            con.Open();
            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
           
            if (Convert.ToInt32(textBox5.Text) > count)
            {
                MessageBox.Show("the number of physics questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox5.Text);

                label8.Text = Convert.ToString(c - d);

                textBox5.Text = "0";
            }

        }
        private void F()
        {

            con.Close();
            con.Open();
            string ct = " SELECT count(ID) FROM exam_management.Questions where course=6";

            MySqlCommand cmdCount = new MySqlCommand(ct, con);

            var count2 = cmdCount.ExecuteScalar();
            int count = Convert.ToInt32(count2);
         
            if (Convert.ToInt32(textBox6.Text) > count)
            {
                MessageBox.Show("the number of ict questions available is " + Convert.ToString(count));
                int c = Convert.ToInt32(label8.Text);
                int d = Convert.ToInt32(textBox6.Text);

                label8.Text = Convert.ToString(c - d);

                textBox6.Text = "0";
            }

        }


        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox1.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox2.Text)) { c = Convert.ToInt32(textBox2.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox3.Text)) { d = Convert.ToInt32(textBox3.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox4.Text)) { h = Convert.ToInt32(textBox4.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox5.Text)) { f = Convert.ToInt32(textBox5.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox6.Text)) { r = Convert.ToInt32(textBox6.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox1.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma2 = Convert.ToInt32(textBox8.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma3 = Convert.ToInt32(textBox9.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma4 = Convert.ToInt32(textBox10.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma5 = Convert.ToInt32(textBox11.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma6 = Convert.ToInt32(textBox12.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma1 = Convert.ToInt32(textBox7.Text); }
                else { ma1 = 0; }

                label14.Text = Convert.ToString(g * ma1);

                A();
            }


        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox2.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox2.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox1.Text)) { c = Convert.ToInt32(textBox1.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox3.Text)) { d = Convert.ToInt32(textBox3.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox4.Text)) { h = Convert.ToInt32(textBox4.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox5.Text)) { f = Convert.ToInt32(textBox5.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox6.Text)) { r = Convert.ToInt32(textBox6.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox2.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma2 = Convert.ToInt32(textBox7.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma3 = Convert.ToInt32(textBox9.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma4 = Convert.ToInt32(textBox10.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma5 = Convert.ToInt32(textBox11.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma6 = Convert.ToInt32(textBox12.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma1 = Convert.ToInt32(textBox8.Text); }
                else { ma1 = 0; }

                label15.Text = Convert.ToString(g * ma1);
                B();
            }

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox3.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox3.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox2.Text)) { c = Convert.ToInt32(textBox2.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox1.Text)) { d = Convert.ToInt32(textBox1.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox4.Text)) { h = Convert.ToInt32(textBox4.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox5.Text)) { f = Convert.ToInt32(textBox5.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox6.Text)) { r = Convert.ToInt32(textBox6.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox3.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma2 = Convert.ToInt32(textBox8.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma3 = Convert.ToInt32(textBox7.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma4 = Convert.ToInt32(textBox10.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma5 = Convert.ToInt32(textBox11.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma6 = Convert.ToInt32(textBox12.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma1 = Convert.ToInt32(textBox9.Text); }
                else { ma1 = 0; }

                label16.Text = Convert.ToString(g * ma1);
                C();
            }

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox4.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox4.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox2.Text)) { c = Convert.ToInt32(textBox2.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox3.Text)) { d = Convert.ToInt32(textBox3.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox1.Text)) { h = Convert.ToInt32(textBox1.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox5.Text)) { f = Convert.ToInt32(textBox5.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox6.Text)) { r = Convert.ToInt32(textBox6.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox4.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma2 = Convert.ToInt32(textBox8.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma3 = Convert.ToInt32(textBox9.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma4 = Convert.ToInt32(textBox7.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma5 = Convert.ToInt32(textBox11.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma6 = Convert.ToInt32(textBox12.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma1 = Convert.ToInt32(textBox10.Text); }
                else { ma1 = 0; }

                label17.Text = Convert.ToString(g * ma1);
                D();
            }

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox5.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox5.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox2.Text)) { c = Convert.ToInt32(textBox2.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox3.Text)) { d = Convert.ToInt32(textBox3.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox4.Text)) { h = Convert.ToInt32(textBox4.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox1.Text)) { f = Convert.ToInt32(textBox1.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox6.Text)) { r = Convert.ToInt32(textBox6.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox5.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma2 = Convert.ToInt32(textBox8.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma3 = Convert.ToInt32(textBox9.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma4 = Convert.ToInt32(textBox10.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma5 = Convert.ToInt32(textBox7.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma6 = Convert.ToInt32(textBox12.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma1 = Convert.ToInt32(textBox11.Text); }
                else { ma1 = 0; }

                label18.Text = Convert.ToString(g * ma1);
                E();
            }



        }
        
        private void textBox6_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(textBox6.Text))
            {
                int c;
                int d;
                int h;
                int f;
                int r;

                int a = Convert.ToInt16(textBox6.Text);
                int b = Convert.ToInt32(label8.Text);

                if (!string.IsNullOrWhiteSpace(textBox2.Text)) { c = Convert.ToInt32(textBox2.Text); }
                else { c = 0; }
                if (!string.IsNullOrWhiteSpace(textBox3.Text)) { d = Convert.ToInt32(textBox3.Text); }
                else { d = 0; }
                if (!string.IsNullOrWhiteSpace(textBox4.Text)) { h = Convert.ToInt32(textBox4.Text); }
                else { h = 0; }
                if (!string.IsNullOrWhiteSpace(textBox5.Text)) { f = Convert.ToInt32(textBox5.Text); }
                else { f = 0; }
                if (!string.IsNullOrWhiteSpace(textBox1.Text)) { r = Convert.ToInt32(textBox1.Text); }
                else { r = 0; }
                label8.Text = Convert.ToString(a + c + d + h + f + r);
                int g = Convert.ToInt32(textBox6.Text);
                int ma1;
                int ma2;
                int ma3;
                int ma4;
                int ma5;
                int ma6;
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma2 = Convert.ToInt32(textBox8.Text); }
                else { ma2 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma3 = Convert.ToInt32(textBox9.Text); }
                else { ma3 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma4 = Convert.ToInt32(textBox10.Text); }
                else { ma4 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma5 = Convert.ToInt32(textBox11.Text); }
                else { ma5 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma6 = Convert.ToInt32(textBox7.Text); }
                else { ma6 = 0; }
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma1 = Convert.ToInt32(textBox12.Text); }
                else { ma1 = 0; }

                label19.Text = Convert.ToString(g * ma1);
                F();
            }
        }

        private void textBox6_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox6.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox6.Text);
                    label8.Text = Convert.ToString(c - d);

                    textBox6.Text = "0";
                }
            }
        }

        private void textBox5_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox5.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox5.Text);
                    label8.Text = Convert.ToString(c - d);

                    textBox5.Text = "0";
                }
            }
        }

        private void textBox4_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox4.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox4.Text);
                    label8.Text = Convert.ToString(c - d);

                    textBox4.Text = "0";
                }
            }
        }

        private void textBox3_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox3.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox3.Text);
                    label8.Text = Convert.ToString(c - d);

                    textBox3.Text = "0";
                }
            }
        }

        private void textBox2_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox2.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox2.Text);
                    label8.Text = Convert.ToString(c - d);

                    textBox2.Text = "0";
                }

            }
        }
        private void textBox1_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox1.Text))
                {
                    int c = Convert.ToInt32(label8.Text);
                    int d = Convert.ToInt32(textBox1.Text);
                    label8.Text = Convert.ToString(c - d);
                    textBox1.Text = "0";
                }
            }
        }

        private void textBox10_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox10.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox4.Text);
                if (!string.IsNullOrWhiteSpace(textBox10.Text)) { ma1 = Convert.ToInt32(textBox10.Text); }
                else { ma1 = 0; }
                label17.Text = Convert.ToString(g * ma1);
                totmark();
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void textBox7_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox7.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox1.Text);
                if (!string.IsNullOrWhiteSpace(textBox7.Text)) { ma1 = Convert.ToInt32(textBox7.Text); }
                else { ma1 = 0; }
                label14.Text = Convert.ToString(g * ma1);
                totmark();

            }
        }

        private void textBox7_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {
            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox7.Text))
                {
                    textBox7.Text = "0";
                }
            }
        }

        private void textBox8_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox8.Text))
                {
                    textBox8.Text = "0";
                }
            }
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox9.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox3.Text);
                if (!string.IsNullOrWhiteSpace(textBox9.Text)) { ma1 = Convert.ToInt32(textBox9.Text); }
                else { ma1 = 0; }
                label16.Text = Convert.ToString(g * ma1);
                totmark();
            }
        }

        private void textBox9_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox9.Text))
                {
                    textBox9.Text = "0";
                }
            }
        }

        private void textBox10_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox10.Text))
                {
                    textBox10.Text = "0";
                }
            }
        }

        private void textBox11_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox11.Text))
                {
                    textBox11.Text = "0";
                }
            }
        }

        private void textBox12_PreviewKeyDown(object sender, PreviewKeyDownEventArgs e)
        {

            if (e.KeyValue == 8)
            {
                if (!string.IsNullOrWhiteSpace(textBox12.Text))
                {
                    textBox12.Text = "0";
                }
            }
        }

        private void textBox8_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox8.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox2.Text);
                if (!string.IsNullOrWhiteSpace(textBox8.Text)) { ma1 = Convert.ToInt32(textBox8.Text); }
                else { ma1 = 0; }
                label15.Text = Convert.ToString(g * ma1);
            }
            totmark();
        }

        private void textBox11_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox11.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox5.Text);
                if (!string.IsNullOrWhiteSpace(textBox11.Text)) { ma1 = Convert.ToInt32(textBox11.Text); }
                else { ma1 = 0; }
                label18.Text = Convert.ToString(g * ma1);
                totmark();
            }
        }

        private void textBox12_TextChanged(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox12.Text))
            {
                int ma1;
                int g = Convert.ToInt32(textBox6.Text);
                if (!string.IsNullOrWhiteSpace(textBox12.Text)) { ma1 = Convert.ToInt32(textBox12.Text); }
                else { ma1 = 0; }
                label19.Text = Convert.ToString(g * ma1);
                totmark();
            }
        }

        private void label8_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }
    } 
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI;
using System.Configuration;
using System.Xml.Linq;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;
using System.Reflection.Emit;
using WindowsFormsApplication1;
using System.Security.Cryptography.X509Certificates;
using System.Drawing.Text;
using MySqlX.XDevAPI.Common;
using System.Threading;
using System.Data.SqlTypes;

namespace windowsFormsApplication1
{
    public partial class first : Form
    {
        public int id = 1;
        Form4 form;

        public first(Form4 frm4)
        {

            InitializeComponent();

            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

            this.form = frm4;

            try
            {
                con.Open();
                string sql = "SELECT * FROM exam_management.arranged_questions WHERE QNNO=1 AND period=@per ";
                string sql2 = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cmd2 = new MySqlCommand(sql2, con);
                MySqlCommand cmd = new MySqlCommand(sql, con);
                int pr = (int)cmd2.ExecuteScalar();
                cmd.Parameters.AddWithValue("@per", pr);
                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    label16.Text = Convert.ToString(reader.GetString("QNNO"));
                    label9.Text = Convert.ToString(reader.GetString("Question"));
                    label12.Text = Convert.ToString(reader.GetString("Choice_1"));
                    label11.Text = Convert.ToString(reader.GetString("Choice_2"));
                    label10.Text = Convert.ToString(reader.GetString("Choice_3"));
                    label13.Text = Convert.ToString(reader.GetString("Choice_4"));
                    label14.Text = Convert.ToString(reader.GetString("Choice_5"));
                    label4.Text = Convert.ToString(reader.GetString("Answer"));

                }


            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally { con.Close(); }

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {



        }
       
        public int Counter;
        public System.Windows.Forms.Timer timer;
        private void Form11_Load(object sender, EventArgs e)
        {
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            label6.Text = form.textBox1.Text;

            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            con.Open();
            MySqlCommand cc = new MySqlCommand("SELECT MAX(period) from exam_management.arranged_questions", con);
            int lm = (int)cc.ExecuteScalar();
            MySqlCommand mySqlCommand = new MySqlCommand("SELECT total_time from exam_management.arranged_questions where period=@per", con);
            mySqlCommand.Parameters.AddWithValue("@per", lm);
            Counter = (int)mySqlCommand.ExecuteScalar();
            if (Counter > 0)
            {
                con.Close();
                timer = new System.Windows.Forms.Timer();
                timer.Interval = 60000;
                timer.Tick += new EventHandler(timer_tick);
                timer.Start();
                label5.Text = Counter.ToString();
            }
            else { label5.Hide();
                label3.Hide();
            }

        }
        private void timer_tick(object sender, EventArgs e)
        {
            Counter--;
            if (Counter== 0)
            {
                timer.Stop();
                MessageBox.Show("time out! Your answers have been submitted ","TIME OUT",MessageBoxButtons.OK,MessageBoxIcon.Warning);
                MySqlConnection conz = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

                conz.Open();
                string sql2 = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cod = new MySqlCommand(sql2, conz);

                MySqlCommand cd = new MySqlCommand("SELECT max(QNNO) from Exam_management.examsession where id=@ids AND period=@per", conz);
                int pr = (int)cod.ExecuteScalar();
                cd.Parameters.AddWithValue("@per", pr);

                cd.Parameters.AddWithValue("@ids", label6.Text);
                int maxi = (int)cd.ExecuteScalar();
                for (int i = 1; i <= maxi; i++)
                {


                    MySqlCommand cmd = new MySqlCommand("select student_answer from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per ", conz);
                    cmd.Parameters.AddWithValue("@ids", label6.Text);
                    cmd.Parameters.AddWithValue("@qno", i);
                    cmd.Parameters.AddWithValue("@per", pr);

                    string sta = (string)cmd.ExecuteScalar();
                    MySqlCommand cmd2 = new MySqlCommand("select Answer from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per", conz);
                    cmd2.Parameters.AddWithValue("@ids", label6.Text);
                    cmd2.Parameters.AddWithValue("@qno", i);
                    cmd2.Parameters.AddWithValue("@per", pr);

                    string ans = (string)cmd2.ExecuteScalar();
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    MySqlCommand cmdf = new MySqlCommand("select each_mark from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per ", conz);
                    cmdf.Parameters.AddWithValue("@ids", label6.Text);
                    cmdf.Parameters.AddWithValue("@qno", i);
                    cmdf.Parameters.AddWithValue("@per", pr);


                    double eachm = (double)cmdf.ExecuteScalar();

                    totm = totm + eachm;

                    if (sta == ans)
                    {

                        mark = mark + eachm;
                    }
                }
                MessageBox.Show("Your result is " + mark + "out of" + totm);

                conz.Close();
                this.Hide();
                Form12 form12 = new Form12();
                form12.Show();


            }
            label5.Text = Counter.ToString();
        }


     


    


    
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
        public double mark = 0;
        public double totm= 0;
        public int count = 0;
        private void button2_Click(object sender, EventArgs e)
        {
            
            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");



            con.Open();
            MySqlCommand cmd10 = new MySqlCommand("Select Max(QNNO) FROM  Exam_management.arranged_questions", con);
            int result = (int)cmd10.ExecuteScalar();
            con.Close();

           

            if (id <= result)
            {
                count++;
                con.Open();
               
                MySqlCommand cmd3 = new MySqlCommand();
                  string sqld = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cmdd = new MySqlCommand(sqld, con);
                cmd3 = new MySqlCommand("UPDATE Exam_management.examsession SET Student_answer=@sa WHERE id=@ids AND QNNO=@qno AND period=@per", con);

                int prd = (int)cmdd.ExecuteScalar();
                cmd3.Parameters.AddWithValue("@per", prd);

                cmd3.Parameters.AddWithValue("@qno", label16.Text);
                cmd3.Parameters.AddWithValue("@ids", label6.Text);
                if (radioButton1.Checked)
                {
                    cmd3.Parameters.AddWithValue("@sa", radioButton1.Text);
                     
                    cmd3.ExecuteNonQuery();
                    if (id < result)
                    {
                        id += 1;
                    }
                }
                else if (radioButton2.Checked)
                {
                    cmd3.Parameters.AddWithValue("@sa", radioButton2.Text);
                      cmd3.ExecuteNonQuery();
                    if (id < result)
                    {
                        id += 1;
                    }
                }
                else if (radioButton3.Checked)
                {
                    cmd3.Parameters.AddWithValue("@sa", radioButton3.Text);
                      cmd3.ExecuteNonQuery();
                    if (id < result)
                    {
                        id += 1;
                    }
                }
                else if (radioButton4.Checked)
                {
                    cmd3.Parameters.AddWithValue("@sa", radioButton4.Text);
                     cmd3.ExecuteNonQuery();
                    if (id < result)
                    {
                        id += 1;
                    }
                }
                else if (radioButton5.Checked)
                {
                    cmd3.Parameters.AddWithValue("@sa", radioButton5.Text);
                     cmd3.ExecuteNonQuery();
                    if (id < result)
                    {
                        id += 1;
                    }
                }
                 else
                {
                   MessageBox.Show("enter your answer first","caution",MessageBoxButtons.OK, MessageBoxIcon.Warning); ;

                }
       
                
               
               

                radioButton1.Checked = false;
                radioButton2.Checked = false;
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                radioButton5.Checked = false;

              }
           
                try
               {
                con.Close();
                    con.Open();
                    string sql = "SELECT * FROM exam_management.arranged_questions Where period=@per AND QNNO=" + id + "";
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                string sql2 = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cmd2 = new MySqlCommand(sql2, con);
                 int pr = (int)cmd2.ExecuteScalar();
                cmd.Parameters.AddWithValue("@per", pr);

                MySqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {

                label9.Text = Convert.ToString(reader.GetString("Question"));
                label12.Text = Convert.ToString(reader.GetString("Choice_1"));
                label11.Text = Convert.ToString(reader.GetString("Choice_2"));
                label10.Text = Convert.ToString(reader.GetString("Choice_3"));
                label13.Text = Convert.ToString(reader.GetString("Choice_4"));
                label14.Text = Convert.ToString(reader.GetString("Choice_5"));
                label16.Text = Convert.ToString(reader.GetString("QNNO"));

                }


                 }
                 catch (Exception ex)
                 {
                     MessageBox.Show(ex.ToString());

                 }
                 finally { con.Close(); 

            } }
      
        
        private void button1_Click(object sender, EventArgs e)
        {
        DialogResult result= MessageBox.Show("are you sure you want to submit Your answers? The exam will be over once you submit!","submit",MessageBoxButtons.YesNo,MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                MessageBox.Show("Your answers have been submitted ");
                MySqlConnection conz = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");

                conz.Open();
                string sql2 = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cod = new MySqlCommand(sql2, conz);

                MySqlCommand cd = new MySqlCommand("SELECT max(QNNO) from Exam_management.examsession where id=@ids AND period=@per", conz);
                int pr = (int)cod.ExecuteScalar();
                cd.Parameters.AddWithValue("@per", pr);

                cd.Parameters.AddWithValue("@ids", label6.Text);
                int maxi = (int)cd.ExecuteScalar();
                for (int i = 1; i <= maxi; i++)
                {


                    MySqlCommand cmd = new MySqlCommand("select student_answer from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per ", conz);
                    cmd.Parameters.AddWithValue("@ids", label6.Text);
                    cmd.Parameters.AddWithValue("@qno", i);
                    cmd.Parameters.AddWithValue("@per", pr);

                    string sta = (string)cmd.ExecuteScalar();
                    MySqlCommand cmd2 = new MySqlCommand("select Answer from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per", conz);
                    cmd2.Parameters.AddWithValue("@ids", label6.Text);
                    cmd2.Parameters.AddWithValue("@qno", i);
                    cmd2.Parameters.AddWithValue("@per", pr);

                    string ans = (string)cmd2.ExecuteScalar();
                    cmd.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    MySqlCommand cmdf = new MySqlCommand("select each_mark from Exam_management.examsession where id=@ids AND QNNO=@qno AND period=@per ", conz);
                    cmdf.Parameters.AddWithValue("@ids", label6.Text);
                    cmdf.Parameters.AddWithValue("@qno", i);
                    cmdf.Parameters.AddWithValue("@per", pr);


                    double eachm = (double)cmdf.ExecuteScalar();

                    totm = totm + eachm;

                    if (sta == ans)
                    {

                        mark = mark + eachm;
                    }
                }
                MessageBox.Show("Your result is " + mark + "out of" + totm);

                conz.Close();
                this.Hide();
                Form12 form12 = new Form12();
                form12.Show();


            }
           

        } 

        private void textBox1_TextChanged_2(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("datasource=localhost;port=3306;username=root;password=");
            id -= 1;
            try
            {
             
                con.Open();
                string sql2 = "SELECT MAX(period) from exam_management.arranged_questions ";
                MySqlCommand cod = new MySqlCommand(sql2, con);

                string sql = "SELECT * FROM exam_management.arranged_questions WHERE period=@per AND QNNO= " + id + "  ";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                int pr = (int)cod.ExecuteScalar();
                cmd.Parameters.AddWithValue("@per", pr);


                MySqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    label16.Text = Convert.ToString(reader.GetString("QNNO"));
                    label9.Text = Convert.ToString(reader.GetString("Question"));
                    label12.Text = Convert.ToString(reader.GetString("Choice_1"));
                    label11.Text = Convert.ToString(reader.GetString("Choice_2"));
                    label10.Text = Convert.ToString(reader.GetString("Choice_3"));
                    label13.Text = Convert.ToString(reader.GetString("Choice_4"));
                    label14.Text = Convert.ToString(reader.GetString("Choice_5"));
                    label4.Text = Convert.ToString(reader.GetString("Answer"));
                    
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally { con.Close(); }
        }
    

        private void button4_Click(object sender, EventArgs e)
        {
            
      
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }
    }
}
        

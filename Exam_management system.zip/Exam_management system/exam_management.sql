-- phpMyAdmin SQL Dump
-- version 5.0.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 25, 2023 at 05:05 PM
-- Server version: 10.4.17-MariaDB
-- PHP Version: 8.0.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `exam_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `FirstName` varchar(100) NOT NULL,
  `LastName` varchar(100) NOT NULL,
  `Password` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`FirstName`, `LastName`, `Password`) VALUES
('firtuna', 'yohanis', 1234),
('abebe', 'kebede', 345);

-- --------------------------------------------------------

--
-- Table structure for table `arranged_questions`
--

CREATE TABLE `arranged_questions` (
  `QNNO` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `Question` varchar(225) NOT NULL,
  `Choice_1` varchar(225) NOT NULL,
  `Choice_2` varchar(225) NOT NULL,
  `Choice_3` varchar(225) NOT NULL,
  `Choice_4` varchar(225) NOT NULL,
  `Choice_5` varchar(225) NOT NULL,
  `Answer` varchar(225) NOT NULL,
  `Course` varchar(225) NOT NULL,
  `each_mark` double NOT NULL,
  `total_time` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `examsession`
--

CREATE TABLE `examsession` (
  `QNNO` int(11) NOT NULL,
  `period` int(11) NOT NULL,
  `id` int(11) NOT NULL,
  `Question` varchar(1000) NOT NULL,
  `Choice_1` varchar(1000) NOT NULL,
  `Choice_2` varchar(1000) NOT NULL,
  `Choice_3` varchar(1000) NOT NULL,
  `Choice_4` varchar(1000) NOT NULL,
  `Choice_5` varchar(1000) NOT NULL,
  `Answer` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `Student_answer` varchar(10) NOT NULL DEFAULT 'z',
  `each_mark` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `questions`
--

CREATE TABLE `questions` (
  `period` int(11) NOT NULL,
  `ID` int(11) NOT NULL,
  `Question` varchar(225) NOT NULL,
  `Choice_1` varchar(225) NOT NULL,
  `Choice_2` varchar(225) NOT NULL,
  `Choice_3` varchar(225) NOT NULL,
  `Choice_4` varchar(225) NOT NULL,
  `Choice_5` varchar(225) NOT NULL,
  `Answer` varchar(225) NOT NULL,
  `Course` int(11) NOT NULL,
  `each_mark` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `questions`
--

INSERT INTO `questions` (`period`, `ID`, `Question`, `Choice_1`, `Choice_2`, `Choice_3`, `Choice_4`, `Choice_5`, `Answer`, `Course`, `each_mark`) VALUES
(0, 1, 'gggh', 'dgfh', 'srzfgdd', 'dgfg', 'Sgf', 'sfgdd', 'B', 2, 3),
(0, 3, 'abcd', 'hfghy', 'yguu', 'uiuyk', 'gjkuhk', 'jkh', 'C', 4, 4),
(0, 4, 'fdgf', 'tgtg', 'rgerg', 'rgrg', 'regreg', 'rger', 'A', 3, 2),
(0, 5, 'rreg', 'rrgrg', 'reert', 'rtrt', 'rtret', '', 'B', 5, 2),
(0, 6, 'fr', 'ssgt', 'ugikuyj', 'xhfyh', 'rtythth', 'uyutyu', 'C', 6, 3),
(0, 2, 'feyghdbs', 'efesf', 'edefe', 'efded', 'ewdsed', 'esdef', 'A', 1, 2),
(0, 7, 'wefrsef', 'efesf', 'ewfesf', 'esfesf', 'efesf', 'efesf', 'B', 1, 3),
(0, 8, 'sdfrdfgvdsz', 'sdcfd', 'dscdc', 'sdcfdcfd', 'dcdfdsf', 'dscdsc', 'A', 1, 3),
(0, 9, 'adefcdv', 'aswxds', 'asxs', 'adsxsadx', 'asdxdas', 'saxsdd', 'C', 1, 3),
(0, 10, 'adcdzc', 'asdxdsx', 'sxsxc', 'zxcdc', 'Xsxsa', 'sxsdsa', 'D', 1, 2),
(0, 11, 'dseded', 'sdfcds', 'sadsds', 'fsefes', 'edefe', 'dee', 'C', 2, 3),
(0, 12, 'esfefe', 'efeeawd', 'edfedf', 'sadse', 'aswad', 'wewewe', 'E', 2, 3),
(0, 13, 'afef', 'QDFEFEW', 'EFEF', 'efess', 'edere', 'edede', 'D', 2, 3),
(0, 14, 'asfdcc', 'adcsdscf', 'asdd', 'asdsd', 'asdd', 'sadsd', 'B', 2, 3),
(0, 15, 'sfrfrsf', 'eadddd', 'saddddd', 'ASWE', 'FDEFRE', 'frfedww', 'A', 4, 0);

-- --------------------------------------------------------

--
-- Table structure for table `students`
--

CREATE TABLE `students` (
  `NUM` int(100) NOT NULL,
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Sex` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `aloowed` varchar(225) NOT NULL DEFAULT 'NO',
  `class` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `students`
--

INSERT INTO `students` (`NUM`, `FirstName`, `LastName`, `Sex`, `Password`, `aloowed`, `class`) VALUES
(346, 'abebe', 'kebede', 'Male', '23224', 'NO', '10'),
(34544, 'kebede', 'al', 'm', '34', 'NO', '10'),
(3445, 'alemitu', 'degu', 'f', 'fdgfh', 'NO', '10');

-- --------------------------------------------------------

--
-- Table structure for table `teachers`
--

CREATE TABLE `teachers` (
  `FirstName` varchar(50) NOT NULL,
  `LastName` varchar(50) NOT NULL,
  `Sex` varchar(50) NOT NULL,
  `Course` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `Email_adress` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `teachers`
--

INSERT INTO `teachers` (`FirstName`, `LastName`, `Sex`, `Course`, `username`, `Password`, `Email_adress`) VALUES
('alemu', 'kebede', 'm', '4', 'alex', '123', 'alex@gmail.com'),
('alemitu', 'degu', 'f', '1', 'ame', '6789', 'ame@gmail.com');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
